﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace OnDemandLoadingData.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult IndexJquery()
        {
            return View();
        }

        public JsonResult LoadPagingData(Int32 RowsPerPage, Int32 PageNumber)
        {
            string ConnectionString = "{Your Connection String}";

            SqlConnection connection = new SqlConnection(ConnectionString);

            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "TESTING_ONDEMAND_PROCEDURE";
            command.Parameters.AddWithValue("RowsPerPage", RowsPerPage);
            command.Parameters.AddWithValue("PageNumber", PageNumber);
            command.Parameters.Add("TotalPage", SqlDbType.Int).Direction = ParameterDirection.Output;
            if (connection.State != ConnectionState.Open) { connection.Open(); }

            SqlDataAdapter dap = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            dap.Fill(dt);

            Int32 TotalPage = 0;
            Int32.TryParse(command.Parameters["TotalPage"].Value.ToString(), out TotalPage);
            string JSON = Newtonsoft.Json.JsonConvert.SerializeObject(dt);

            LazyLoading oData = new LazyLoading();
            oData.Data = JSON;
            oData.TotalPage = TotalPage;

            return Json(oData, JsonRequestBehavior.AllowGet);
        }

        public class LazyLoading
        {
            //Hold JSON Data
            public string Data { get; set; }
            // Hold Total Pages
            public int TotalPage { get; set; }
        }
    }
}